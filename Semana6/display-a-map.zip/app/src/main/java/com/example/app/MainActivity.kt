
package com.example.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.arcgismaps.ApiKey
import com.arcgismaps.ArcGISEnvironment
import com.arcgismaps.httpcore.authentication.OAuthUserConfiguration
import com.arcgismaps.toolkit.authentication.AuthenticatorState
import com.arcgismaps.toolkit.authentication.DialogAuthenticator
import com.example.app.screens.MainScreen
import com.example.app.ui.theme.TutorialTheme

class MainActivity : ComponentActivity() {

    private enum class AuthenticationMode { API_KEY, USER_AUTH }

    private val authenticationMode = AuthenticationMode.API_KEY

    private val authenticatorState = AuthenticatorState()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        when (authenticationMode) {
            AuthenticationMode.API_KEY -> {

                ArcGISEnvironment.apiKey = ApiKey.create("YOUR_ACCESS_TOKEN")

            }

            AuthenticationMode.USER_AUTH -> {
                authenticatorState.oAuthUserConfigurations = listOf(
                    OAuthUserConfiguration(
                        portalUrl = "https://www.arcgis.com",

                        clientId = "YOUR_CLIENT_ID",
                        redirectUrl = "YOUR_REDIRECT_URL"

                    )
                )

            }
        }

        enableEdgeToEdge()

        setContent {
            TutorialTheme {
                MainScreen()

                if (authenticationMode == AuthenticationMode.USER_AUTH) {
                    DialogAuthenticator(authenticatorState)
                }

            }
        }
    }

}


